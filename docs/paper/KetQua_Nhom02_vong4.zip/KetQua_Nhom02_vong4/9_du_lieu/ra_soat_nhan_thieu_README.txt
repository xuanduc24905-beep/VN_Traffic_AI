Xe yolov8x bat duoc ma nhan goc khong co (V5 train). CHI DE XEM — chua sua nhan nao.
Detector yolov8x.pt imgsz=1280 conf>=0.4; thieu = IoU<0.3 voi moi hop goc va nam trong hop goc <60%.
Mau: xanh la mong = nhan goc; do = v8x de xuat (lop + conf). Ten file: r0001 = anh thieu nhieu nhat, missK = so xe thieu.
Luu y: v8x co the bat nham (bong, bien quang cao, xe lam, xe dap) — day la DE XUAT, can nguoi duyet.
proposals/*.txt = hop de xuat dang YOLO 4 lop (0 motorcycle, 1 car, 2 bus, 3 truck).

cantho: 174/259 anh co xe thieu; nhan goc 1867 hop; de xuat thieu 346 hop {'car': 322, 'truck': 11, 'bus': 12, 'motorcycle': 1}
soict24: 410/879 anh co xe thieu; nhan goc 8023 hop; de xuat thieu 753 hop {'car': 379, 'truck': 144, 'bus': 187, 'motorcycle': 43}
soictnight: 187/1385 anh co xe thieu; nhan goc 8921 hop; de xuat thieu 234 hop {'car': 178, 'bus': 44, 'truck': 10, 'motorcycle': 2}
vnv3: 149/310 anh co xe thieu; nhan goc 1470 hop; de xuat thieu 537 hop {'car': 341, 'truck': 105, 'bus': 59, 'motorcycle': 32}
