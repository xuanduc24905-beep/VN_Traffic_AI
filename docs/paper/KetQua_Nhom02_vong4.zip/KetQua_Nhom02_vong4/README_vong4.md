# KetQua_Nhom02_vong4

Gom toan bo noi dung KetQua_Nhom02_vong3 va them cac tep sau (nguon cua cac cho sua trong ban v3 moi):

| Thu muc / tep | Dung cho |
|---|---|
| 5_toc_do/speed_eval_mode.json | So toc do 6,66 ms (YOLOv8s-CW) va 42,36 ms (Faster R-CNN), ty le 6,4 lan, do o dung che do cham diem tren 1.500 anh. speed_cw.json (so 4,9 lan cu) giu lai de doi chieu. |
| scripts/86_speed_eval_mode.py, scripts/50_speed_benchmark.py | Ma do toc do. Trong 50_speed_benchmark.py, YOLO goi predict() tren duong dan anh ben trong dong ho (tinh ca doc anh), Faster R-CNN doc anh truoc khi bam gio: ly do bo so 9,75 / 47,66 ms. |
| 8_cham_lai_960/eval_960_recheck.json | p4_imgsz1280 va r_progressive cham lai o anh 960: 0,7849 va 0,7841. |
| 8_cham_lai_960/detector_eval.json | So goc trong Bang III, V, VI (hai mo hinh tren cham o 1.280). |
| 9_du_lieu/kiem_tra_mo_ta_du_lieu.json | Buoc so thu tu khung cua tung camera, video Can Tho, 420 anh v10 chi co xe ba gac, 11 hop trung, epoch diem luu tot nhat cua moi luot (6 luot doi chung deu o epoch 1). |
| 9_du_lieu/data_audit_summary.txt | Kiem tra toan ven nhan (duplicate_bboxes 9 / 0 / 2). |
| 9_du_lieu/ra_soat_nhan_thieu_README.txt | Ra soat xe thieu nhan tren tap huan luyen (SOICT 2024: 753 de xuat / 8.023 hop). |
| 9_du_lieu/cantho_4_video.jpg | Bon video Can Tho cung mot camera. |
| scripts/91_kiem_tra_mo_ta_du_lieu.py, scripts/build_v5plus_merged.py | Ma sinh 9_du_lieu va ma gop V5+ (bo anh khong con hop nao sau khi loai xe ba gac). |
